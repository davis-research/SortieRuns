# SORTIE-ND Runs: 10-30-15

This set of runs is designed to address the seed/seedling recruitment issue. As it stands, seedling recruitment is not well modeled. I'm not sure if the problem is occurring in the seed production, seed establishment, or seedling survival stages. I'm going to try messing with seedling survival, first, and then I'll try messing with the dispersal curves. 

